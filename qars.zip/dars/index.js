// async function getData() {
//   let data = await fetch("https://fakestoreapi.com/products?limit=10");

//   if (data.ok) {
//     data = await data.json();
//   }
//   console.log("data", data);
// }
  
// getData();
 
        // Saqlangan ismni olish
        function loadName() {
            const savedName = localStorage.getItem('userName');
            if (savedName) {
                document.getElementById('nameDisplay').innerText = 'Sizning ismingiz: ' + savedName;
            }
        }

        // Ismni saqlash
        function saveName() {
            const name = document.getElementById('nameInput').value;
            localStorage.setItem('userName', name);
            loadName(); // Ismni yangilash
        }

        // Sahifa yuklanganda ismni yuklash
        window.onload = loadName;
    